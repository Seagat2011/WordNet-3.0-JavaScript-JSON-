var mysql_wn_data_parts_of_speech = {
	'n':'noun',
	'v':'verb',
	'a':'adjective',
	'r':'adverb',
	's':'adjective satellite',
}