var mysql_wn_data_adjpositiontype = [
	'p':'predicate',
	'a':'attributive',
	'ip':'immediately postnominal',
]